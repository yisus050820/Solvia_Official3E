import React from 'react';
import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import Registro from './componentes/Registro';
import Login from './componentes/Login';
import dashboardAdmin from './componentes/dashboardAdmin';
import dashboardDonante from './componentes/dashboardDonante';

function App() {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<dashboardAdmin />} />
        <Route path="/register" element={<Registro />} />
        <Route path="/login" element={<Login />} />
        <Route path="/Admin" element={<dashboardAdmin />} />
        {/*<Route path="/donor-dashboard" element={<dashboardDonante />} />
        <Route path="/volunteer-dashboard" element={<VolunteerDashboard />} />
        <Route path="/beneficiary-dashboard" element={<BeneficiaryDashboard />} />
        <Route path="/coordinator-dashboard" element={<CoordinatorDashboard />} />*/}
      </Routes>
    </AnimatePresence>
  );
}

export default function AnimatedApp() {
  return (
    <Router>
      <App />
    </Router>
  );
}
