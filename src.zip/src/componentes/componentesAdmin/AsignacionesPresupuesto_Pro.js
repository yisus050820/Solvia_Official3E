import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, Typography, Grid, MenuItem, Select, FormControl, InputLabel, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, TextField } from '@mui/material';
import { motion, AnimatePresence } from 'framer-motion';
import { FaPlus, FaTrashAlt, FaEdit } from 'react-icons/fa';

const AsignacionPresupuesto_Pro = () => {
  const [programaSeleccionado, setProgramaSeleccionado] = useState('');
  const [presupuesto, setPresupuesto] = useState('');
  const [asignaciones, setAsignaciones] = useState([]);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [currentId, setCurrentId] = useState(null);
  const [programas, setProgramas] = useState([]);
  const [errors, setErrors] = useState({ programError: '', amountError: '', alreadyAssignedError: '' });

  useEffect(() => {
    // Obtener programas y asignaciones
    axios.get('http://localhost:5000/asigVolProg/programas')
      .then(res => {
        setProgramas(res.data);
      })
      .catch(err => console.error('Error fetching programs:', err));

    axios.get('http://localhost:5000/asigPresProg/asignaciones')
      .then(res => {
        setAsignaciones(res.data);
      })
      .catch(err => console.error('Error fetching assignments:', err));
  }, []);

  const validateFields = () => {
    let isValid = true;
    const newErrors = { programError: '', amountError: '', alreadyAssignedError: '' };

    if (!programaSeleccionado) {
      newErrors.programError = 'El programa es requerido.';
      isValid = false;
    }
    if (!presupuesto || presupuesto <= 0) {
      newErrors.amountError = 'El presupuesto debe ser mayor a 0.';
      isValid = false;
    }

    // Verificar si el programa ya tiene presupuesto asignado
    const programaYaAsignado = asignaciones.some(asign => asign.program_id === programaSeleccionado);
    if (programaYaAsignado && !isEditModalOpen) {
      newErrors.alreadyAssignedError = 'Este programa ya tiene un presupuesto asignado.';
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleAsignar = () => {
    if (!validateFields()) return;

    axios.get('http://localhost:5000/asigPresProg/disponible')
      .then(res => {
        const dineroDisponible = res.data.dineroDisponible;
        if (presupuesto > dineroDisponible) {
          setErrors(prev => ({ ...prev, amountError: 'El presupuesto excede el dinero disponible.' }));
          return;
        }

        const nuevaAsignacion = {
          program_id: programaSeleccionado,
          presupuesto: presupuesto,
          date: new Date(),
        };

        axios.post('http://localhost:5000/asigPresProg/asignacion', nuevaAsignacion)
          .then(res => {
            const newAssignment = {
              ...nuevaAsignacion,
              id: res.data.data,
              programa: programas.find(p => p.id === programaSeleccionado)?.name,
            };
            setAsignaciones([...asignaciones, newAssignment]);
            setProgramaSeleccionado('');
            setPresupuesto('');
            setErrors({ programError: '', amountError: '', alreadyAssignedError: '' });
          })
          .catch(err => console.error('Error al asignar presupuesto:', err));
      })
      .catch(err => console.error('Error al verificar el presupuesto disponible:', err));
  };

  const handleEditar = (asignacion) => {
    setProgramaSeleccionado(asignacion.program_id);
    setPresupuesto(asignacion.presupuesto);
    setCurrentId(asignacion.id);
    setIsEditModalOpen(true);
  };

  const confirmEdit = () => {
    if (!validateFields()) return;

    axios.get('http://localhost:5000/asigPresProg/disponible')
      .then(res => {
        const disponible = res.data.dineroDisponible;
        if (parseFloat(presupuesto) > disponible) {
          setErrors(prev => ({ ...prev, amountError: 'El presupuesto excede la cantidad disponible.' }));
          return;
        }

        const datosEditados = {
          program_id: programaSeleccionado,
          presupuesto: presupuesto,
          date: new Date(),
        };

        axios.put(`http://localhost:5000/asigPresProg/asignacion/${currentId}`, datosEditados)
          .then(() => {
            const nuevasAsignaciones = asignaciones.map(asignacion =>
              asignacion.id === currentId ? { ...asignacion, ...datosEditados } : asignacion
            );
            setAsignaciones(nuevasAsignaciones);
            setIsEditModalOpen(false);
            setProgramaSeleccionado('');
            setPresupuesto('');
            setErrors({ programError: '', amountError: '', alreadyAssignedError: '' });
          })
          .catch(err => console.error('Error updating assignment:', err));
      })
      .catch(err => console.error('Error fetching available budget:', err));
  };

  const handleEliminar = (id) => {
    setIsDeleteConfirmOpen(true);
    setCurrentId(id);
  };

  const confirmDelete = () => {
    axios.delete(`http://localhost:5000/asigPresProg/asignacion/${currentId}`)
      .then(() => {
        setAsignaciones(asignaciones.filter(asignacion => asignacion.id !== currentId));
        setIsDeleteConfirmOpen(false);
      })
      .catch(err => console.error('Error deleting assignment:', err));
  };

  const buttonVariants = {
    hover: { scale: 1.05, transition: { duration: 0.3 } },
    tap: { scale: 0.95, transition: { duration: 0.2 } },
  };

  return (
    <motion.div
      className="max-w-6xl mx-auto mt-10"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card sx={{ backgroundColor: '#1e293b', color: '#fff', padding: '20px', borderRadius: '15px' }}>
        <CardContent>
          <Typography variant="h4" color="white" gutterBottom>
            Asignar Presupuesto a Programa
          </Typography>
          <Grid container spacing={4}>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth sx={{ backgroundColor: '#fff', borderRadius: '5px' }}>
                <InputLabel>Selecciona un Programa</InputLabel>
                <Select
                  value={programaSeleccionado}
                  onChange={(e) => setProgramaSeleccionado(e.target.value)}
                  disabled={isEditModalOpen} // Deshabilitado en edición
                  sx={{
                    '.MuiSelect-select': {
                      color: programaSeleccionado ? 'black' : 'inherit',
                    }
                  }}
                >
                  {programas.map((programa) => (
                    <MenuItem key={programa.id} value={programa.id}>
                      {programa.name}
                    </MenuItem>
                  ))}
                </Select>
                <span style={{ color: 'red' }}>{errors.programError}</span>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Presupuesto (MXN)"
                value={presupuesto}
                onChange={(e) => setPresupuesto(e.target.value)}
                sx={{ backgroundColor: '#fff', borderRadius: '5px' }}
                error={!!errors.amountError}
              />
              <span style={{ color: 'red' }}>{errors.amountError}</span>
              <span style={{ color: 'red' }}>{errors.alreadyAssignedError}</span>
            </Grid>
          </Grid>

          <div className="mt-6 flex justify-end">
            <motion.button
              className="bg-green-500 text-white px-4 py-2 rounded-full"
              variants={buttonVariants}
              whileHover="hover"
              whileTap="tap"
              onClick={handleAsignar}
            >
              <FaPlus />
            </motion.button>
          </div>

          {/* Tabla de Asignaciones */}
          <TableContainer component={Paper} sx={{ marginTop: '20px', backgroundColor: '#2d3748' }}>
            <Table>
              <TableHead sx={{ backgroundColor: '#4a5568' }}>
                <TableRow>
                  <TableCell sx={{ color: '#fff' }}>Programa</TableCell>
                  <TableCell sx={{ color: '#fff' }}>Presupuesto Asignado (MXN)</TableCell>
                  <TableCell sx={{ color: '#fff' }}>Fecha</TableCell>
                  <TableCell sx={{ color: '#fff' }}>Acciones</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <AnimatePresence>
                  {asignaciones.map((asignacion) => (
                    <motion.tr
                      key={asignacion.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                    >
                      <TableCell sx={{ color: '#fff' }}>{asignacion.programa}</TableCell>
                      <TableCell sx={{ color: '#fff' }}>{asignacion.presupuesto}</TableCell>
                      <TableCell sx={{ color: '#fff' }}>{new Date(asignacion.date).toLocaleDateString()}</TableCell>
                      <TableCell sx={{ color: '#fff' }}>
                        <motion.button
                          onClick={() => handleEditar(asignacion)}
                          variants={buttonVariants}
                          whileHover="hover"
                          whileTap="tap"
                        >
                          <FaEdit />
                        </motion.button>
                        <motion.button
                          onClick={() => handleEliminar(asignacion.id)}
                          variants={buttonVariants}
                          whileHover="hover"
                          whileTap="tap"
                        >
                          <FaTrashAlt />
                        </motion.button>
                      </TableCell>
                    </motion.tr>
                  ))}
                </AnimatePresence>
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* Modal Confirmar Eliminación */}
      <Dialog open={isDeleteConfirmOpen} onClose={() => setIsDeleteConfirmOpen(false)}>
        <DialogTitle>Confirmar eliminación</DialogTitle>
        <DialogContent>
          <DialogContentText>¿Estás seguro de eliminar esta asignación?</DialogContentText>
        </DialogContent>
        <DialogActions>
          <motion.button onClick={() => setIsDeleteConfirmOpen(false)}>Cancelar</motion.button>
          <motion.button onClick={confirmDelete}>Eliminar</motion.button>
        </DialogActions>
      </Dialog>

      {/* Modal Editar */}
      <Dialog open={isEditModalOpen} onClose={() => setIsEditModalOpen(false)}>
        <DialogTitle>Editar Asignación</DialogTitle>
        <DialogContent>
          <DialogContentText>Modifica el presupuesto asignado.</DialogContentText>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Presupuesto (MXN)"
                value={presupuesto}
                onChange={(e) => setPresupuesto(e.target.value)}
                error={!!errors.amountError}
              />
              <span style={{ color: 'red' }}>{errors.amountError}</span>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <motion.button onClick={() => setIsEditModalOpen(false)}>Cancelar</motion.button>
          <motion.button onClick={confirmEdit}>Confirmar</motion.button>
        </DialogActions>
      </Dialog>
    </motion.div>
  );
};

export default AsignacionPresupuesto_Pro;
